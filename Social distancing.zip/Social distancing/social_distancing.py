#!/usr/bin/env python

import argparse
import cv2
import math
import message_filters
import numpy as np
import os
import rospy
import rospkg
import time
from cv_bridge import CvBridge
from sensor_msgs.msg import Image

# Get the package directory
rospack = rospkg.RosPack()
cd = rospack.get_path('cob_people_object_detection_tensorflow')

class SocialDistancingNode(object):
	def __init__(self):
		super(SocialDistancingNode, self).__init__()

		# init the node
		rospy.init_node('social_distancing_node', anonymous=False)

		# Get the parameters
		(image_topic, output_topic, output_topic_rgb) = self.get_parameters()

		self._bridge = CvBridge()
		self.pub_det_rgb = rospy.Publisher(output_topic_rgb,Image,queue_size=1)
		self.sub_image = message_filters.Subscriber(image_topic, Image)

		# Scaling factor for face recognition image
		self.scaling_factor = 1.0
		self.initialize_model()
		ts = message_filters.ApproximateTimeSynchronizer([self.sub_image],1,0.3)
		ts.registerCallback(self.detection_callback)
		rospy.spin()

	def get_parameters(self):
		"""
        Gets the necessary parameters from parameter server
        Args:
        Returns:
        (tuple) (camera_topic, output_topic)
        """
		camera_topic = rospy.get_param("~camera_topic")
		output_topic = rospy.get_param("~output_topic")
		output_topic_rgb = rospy.get_param("~output_topic_rgb")
		return (camera_topic, output_topic, output_topic_rgb)

	def shutdown(self):
		"""
        Shuts down the node
        """
		rospy.signal_shutdown("See ya!")

	def detection_callback(self, image):
		"""
        Callback for RGB images and detections

        Args:
        detections (cob_perception_msgs/DetectionArray) : detections array
        image (sensor_msgs/Image): RGB image from camera

        """
		cv_rgb = self._bridge.imgmsg_to_cv2(image, "passthrough")[:, :, ::-1]
		cv_rgb = cv2.resize(cv_rgb, (0, 0), fx=self.scaling_factor, fy=self.scaling_factor)
		cv_rgb = cv_rgb.astype(np.uint8)
		cv_rgb = self.detect(cv_rgb)
		image_outgoing = self._bridge.cv2_to_imgmsg(cv_rgb, encoding="passthrough")
		self.publish(image_outgoing)

	def publish(self,image_outgoing):
		"""
        Creates the ros messages and publishes them

        Args:
        detections (cob_perception_msgs/DetectionArray): incoming detections
        image_outgoing (sensor_msgs/Image): with face bounding boxes and labels
        """
		self.pub_det_rgb.publish(image_outgoing)

	def initialize_model(self):
		print("[INFO] Loading social distancing model...")
		configPath = cd + "/src/social_distance/yolov3.cfg"
		weightsPath = cd + "/src/social_distance/yolov3.weights"
		self.net = cv2.dnn.readNetFromDarknet(configPath, weightsPath)

	def detect(self, image):
		(H, W) = image.shape[:2]
		ln = self.net.getLayerNames()
		ln = [ln[i[0] - 1] for i in self.net.getUnconnectedOutLayers()]
		blob = cv2.dnn.blobFromImage(image, 1 / 255.0, (416, 416),swapRB=True, crop=False)
		self.net.setInput(blob)
		start = time.time()
		layerOutputs = self.net.forward(ln)
		end = time.time()
		print("Frame Prediction Time : {:.6f} seconds".format(end - start))
		boxes = []
		confidences = []
		classIDs = []
		for output in layerOutputs:
		    for detection in output:
		        scores = detection[5:]
		        classID = np.argmax(scores)
		        confidence = scores[classID]
		        if confidence > 0.5 and classID == 0:
		            box = detection[0:4] * np.array([W, H, W, H])
		            (centerX, centerY, width, height) = box.astype("int")
		            x = int(centerX - (width / 2))
		            y = int(centerY - (height / 2))
		            boxes.append([x, y, int(width), int(height)])
		            confidences.append(float(confidence))
		            classIDs.append(classID)

		idxs = cv2.dnn.NMSBoxes(boxes, confidences, 0.5,0.3)
		ind = []
		for i in range(0,len(classIDs)):
		    if(classIDs[i]==0):
		        ind.append(i)
		a = []
		b = []
		color = (0,255,0)
		if len(idxs) > 0:
		        for i in idxs.flatten():
		            (x, y) = (boxes[i][0], boxes[i][1])
		            (w, h) = (boxes[i][2], boxes[i][3])
		            a.append(x)
		            b.append(y)
		            cv2.rectangle(image, (x, y), (x + w, y + h), color, 2)

		distance=[]
		nsd = []
		for i in range(0,len(a)-1):
		    for k in range(1,len(a)):
		        if(k==i):
		            break
		        else:
		            x_dist = (a[k] - a[i])
		            y_dist = (b[k] - b[i])
		            d = math.sqrt(x_dist * x_dist + y_dist * y_dist)
		            distance.append(d)
		            if(d<=100.0):
		                nsd.append(i)
		                nsd.append(k)
		            nsd = list(dict.fromkeys(nsd))

		color = (0, 0, 255)
		text=""
		for i in nsd:
		    (x, y) = (boxes[i][0], boxes[i][1])
		    (w, h) = (boxes[i][2], boxes[i][3])
		    cv2.rectangle(image, (x, y), (x + w, y + h), color, 2)
		    text = "Alert"
		    cv2.putText(image, text, (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX,0.5, color, 2)

		cv2.putText(image, text, (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX,0.5, color, 2)
		cv2.imshow("Social Distancing Detector", image)
		return image

def main():
	""" main function
    """
	node = SocialDistancingNode()

if __name__ == '__main__':
	main()
