#!/usr/bin/env python

# import the necessary packages
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
import numpy as np
import argparse
import cv2
import os
import glob
import rospy
import rospkg
import message_filters
import numpy as np
import cv2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image

# Get the package directory
rospack = rospkg.RosPack()
cd = rospack.get_path('cob_people_object_detection_tensorflow')

class MaskDetectionNode(object):
	def __init__(self):
		super(MaskDetectionNode, self).__init__()

		# init the node
		rospy.init_node('mask_recognition_node', anonymous=False)

		# Get the parameters
		(image_topic, output_topic, output_topic_rgb) \
			= self.get_parameters()

		self._bridge = CvBridge()
		self.pub_det_rgb = rospy.Publisher(output_topic_rgb, \
										   Image, queue_size=1)
		self.sub_image = message_filters.Subscriber(image_topic, Image)
		# Scaling factor for face recognition image
		self.scaling_factor = 1.0

		self.initialize_model()

		ts = message_filters.ApproximateTimeSynchronizer( \
			[self.sub_image], 1, 0.3)

		ts.registerCallback(self.detection_callback)
		# spin
		rospy.spin()

	def get_parameters(self):
		"""
        Gets the necessary parameters from parameter server

        Args:

        Returns:
        (tuple) (camera_topic, output_topic)

        """
		camera_topic = rospy.get_param("~camera_topic")
		output_topic = rospy.get_param("~output_topic")
		output_topic_rgb = rospy.get_param("~output_topic_rgb")

		return (camera_topic, output_topic, output_topic_rgb)

	def shutdown(self):
		"""
        Shuts down the node
        """
		rospy.signal_shutdown("See ya!")

	def detection_callback(self, image):
		"""
        Callback for RGB images and detections

        Args:
        detections (cob_perception_msgs/DetectionArray) : detections array
        image (sensor_msgs/Image): RGB image from camera

        """
		cv_rgb = self._bridge.imgmsg_to_cv2(image, "passthrough")[:, :, ::-1]

		cv_rgb = cv2.resize(cv_rgb, (0, 0), fx=self.scaling_factor, fy=self.scaling_factor)

		cv_rgb = cv_rgb.astype(np.uint8)

		cv_rgb = self.detect(cv_rgb)

		image_outgoing = self._bridge.cv2_to_imgmsg(cv_rgb, encoding="passthrough")

		self.publish(image_outgoing)

	def publish(self,image_outgoing):
		"""
        Creates the ros messages and publishes them

        Args:
        detections (cob_perception_msgs/DetectionArray): incoming detections
        image_outgoing (sensor_msgs/Image): with face bounding boxes and labels

        """
		self.pub_det_rgb.publish(image_outgoing)

	def initialize_model(self):
		print("[INFO] loading mask detector model...")
		prototxtPath = cd + "/src/mask_detection/deploy.prototxt"
		weightsPath = cd + "/src/mask_detection/res10_300x300_ssd_iter_140000.caffemodel"
		self.net = cv2.dnn.readNet(prototxtPath, weightsPath)
		modelPath = cd + "/src/mask_detection/mask_detector.model"
		self.model = load_model(modelPath)

	def detect(self, image):
		(h, w) = image.shape[:2]

		# construct a blob from the image
		blob = cv2.dnn.blobFromImage(image, 1.0, (300, 300),
			(104.0, 177.0, 123.0))

		# pass the blob through the network and obtain the face detections
		# print("[INFO] computing face detections...")
		self.net.setInput(blob)
		detections = self.net.forward()

		# loop over the detections
		for i in range(0, detections.shape[2]):
			# extract the confidence (i.e., probability) associated with
			# the detection
			confidence = detections[0, 0, i, 2]

			# filter out weak detections by ensuring the confidence is
			# greater than the minimum confidence
			if confidence > 0.8:
				# compute the (x, y)-coordinates of the bounding box for
				# the object
				box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
				(startX, startY, endX, endY) = box.astype("int")

				# ensure the bounding boxes fall within the dimensions of
				# the frame
				(startX, startY) = (max(0, startX), max(0, startY))
				(endX, endY) = (min(w - 1, endX), min(h - 1, endY))

				# extract the face ROI, convert it from BGR to RGB channel
				# ordering, resize it to 224x224, and preprocess it
				face = image[startY:endY, startX:endX]
				face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
				face = cv2.resize(face, (224, 224))
				face = img_to_array(face)
				face = preprocess_input(face)
				face = np.expand_dims(face, axis=0)

				# pass the face through the model to determine if the face
				# has a mask or not
				(mask, withoutMask) = self.model.predict(face)[0]

				# determine the class label and color we'll use to draw
				# the bounding box and text
				label = "Mask" if mask > withoutMask else "No Mask"
				print("[INFO]:",label)
				color = (0, 255, 0) if label == "Mask" else (0, 0, 255)

				# include the probability in the label
				label = "{}: {:.2f}%".format(label, max(mask, withoutMask) * 100)

				# display the label and bounding box rectangle on the output
				# frame
				cv2.putText(image, label, (startX, startY - 10),
					cv2.FONT_HERSHEY_SIMPLEX, 0.45, color, 2)
				cv2.rectangle(image, (startX, startY), (endX, endY), color, 2)
		return image

def main():
	""" main function
    """
	node = MaskDetectionNode()

if __name__ == '__main__':
	main()
